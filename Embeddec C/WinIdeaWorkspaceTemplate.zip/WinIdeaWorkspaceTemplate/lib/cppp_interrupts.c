#include "pdl.h"
#define __INTERRUPTS_FM4_TYPE_B_C__
#include "interrupts_fm4_type_b.c"